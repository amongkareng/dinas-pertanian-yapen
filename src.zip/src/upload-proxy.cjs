const express = require("express");
const cors = require("cors");
const multer = require("multer");
const admin = require("firebase-admin");
const { getStorage } = require("firebase-admin/storage");
const ServiceAccount = require("./ServiceAccount.json");

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ storage: multer.memoryStorage() });

admin.initializeApp({
  credential: admin.credential.cert(ServiceAccount),
  storageBucket: "dinasyapen-admin.firebasestorage.app",
});

const bucket = getStorage().bucket();

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const file = req.file;
    const filename = `berita/${Date.now()}-${file.originalname}`;
    const blob = bucket.file(filename);
    const blobStream = blob.createWriteStream({
      metadata: { contentType: file.mimetype },
    });

    blobStream.on("error", (err) => {
      console.error("Upload error:", err);
      res.status(500).send("Upload error");
    });

    blobStream.on("finish", async () => {
      const publicUrl = `https://storage.googleapis.com/${bucket.name}/${filename}`;
      res.status(200).json({ url: publicUrl });
    });

    blobStream.end(file.buffer);
  } catch (error) {
    console.error(error);
    res.status(500).send("Something went wrong");
  }
});

app.listen(4000, () => {
  console.log("✅ Proxy upload server running on http://localhost:4000");
});

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FaChevronDown, FaBars, FaTimes } from "react-icons/fa";
import logo from "../assets/logo_dinas.svg";

const Header = () => {
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleDropdown = (key) => {
    setActiveDropdown(activeDropdown === key ? null : key);
  };

  const closeMenu = () => {
    setMenuOpen(false);
    setActiveDropdown(null);
  };

  const navItems = [
    { name: "Beranda", to: "/" },
    {
      name: "Profil",
      dropdown: [
        { name: "Visi & Misi", to: "/visimisi" },
        { name: "Struktur Dinas", to: "/struktur" },
      ],
    },
    {
      name: "Program",
      dropdown: [{ name: "Program dan Kegiatan", to: "/program" }],
    },
    {
      name: "Informasi",
      dropdown: [{ name: "Berita", to: "/news" }],
    },
  ];

  return (
    <header className="bg-[color:var(--color-brand)] text-white shadow-md sticky top-0 z-50">
      <div className="container flex items-center justify-between py-3">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="Logo Dinas" className="w-14 h-14" />
          <div className="font-bold leading-5 text-sm sm:text-base">
            <span className="block text-white">Dinas Pertanian</span>
            <span className="block text-white">Kabupaten Kepulauan Yapen</span>
          </div>
        </Link>

        {/* Desktop Menu */}
        <nav className="hidden md:flex gap-6 text-sm font-medium relative">
          {navItems.map((item, idx) => (
            <div key={idx} className="relative">
              {item.dropdown ? (
                <>
                  <button
                    onClick={() => toggleDropdown(item.name)}
                    className="flex items-center gap-1 hover:underline"
                  >
                    {item.name} <FaChevronDown size={12} />
                  </button>
                  {activeDropdown === item.name && (
                    <div className="absolute top-full left-0 mt-2 bg-white text-black shadow rounded text-sm p-2 w-40 z-50">
                      {item.dropdown.map((sub, subIdx) => (
                        <Link
                          to={sub.to}
                          key={subIdx}
                          className="block hover:text-green-700 py-1 px-2"
                          onClick={closeMenu}
                        >
                          {sub.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <Link to={item.to} className="hover:underline">
                  {item.name}
                </Link>
              )}
            </div>
          ))}
        </nav>

        {/* Hamburger Icon */}
        <button
          className="md:hidden text-xl"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {menuOpen && (
        <div className="md:hidden bg-white text-black shadow-inner py-4 px-6 space-y-4">
          {navItems.map((item, idx) => (
            <div key={idx} className="">
              {item.dropdown ? (
                <div>
                  <button
                    onClick={() => toggleDropdown(item.name)}
                    className="flex justify-between w-full items-center font-medium"
                  >
                    {item.name} <FaChevronDown size={12} />
                  </button>
                  {activeDropdown === item.name && (
                    <div className="mt-2 ml-3 space-y-2">
                      {item.dropdown.map((sub, subIdx) => (
                        <Link
                          to={sub.to}
                          key={subIdx}
                          className="block text-sm hover:text-green-700"
                          onClick={closeMenu}
                        >
                          {sub.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  to={item.to}
                  className="block font-medium"
                  onClick={closeMenu}
                >
                  {item.name}
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </header>
  );
};

export default Header;

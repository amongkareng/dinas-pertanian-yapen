import React, { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
import hero from "../assets/hero_nobg.png";
import { Link } from "react-router-dom";

const Hero = () => {
  useEffect(() => {
    AOS.init({
      duration: 2000,
      delay: 200,
      once: false,
    });
  }, []);

  return (
    <section
      id="hero"
      className="relative pt-24 sm:pt-32 bg-primary text-white overflow-hidden"
    >
      <div className="wrapper flex flex-col md:flex-row items-center gap-10">
        {/* Teks Hero */}
        <div
          className="flex-1 text-center md:text-left px-4 sm:px-0"
          data-aos="fade-right"
        >
          <h1 className="text-4xl sm:text-5xl   font-bold leading-tight mb-6">
            Selamat Datang di Website Resmi Pemerintah Daerah
            <span className="text-gradient"> Kabupaten Yapen</span>
          </h1>
          <p className="text-light-200 text-black max-w-xl mx-auto md:mx-0 text-lg mb-8">
            Dapatkan informasi terkini seputar program pertanian, layanan
            publik, dan kebijakan terbaru yang mendukung kesejahteraan
            masyarakat.
          </p>
          <Link
            to={"/news"}
            className="inline-block bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300"
          >
            Lihat Berita Terbaru
          </Link>
        </div>

        {/* Gambar Hero */}
        <div className="flex-1 flex justify-center" data-aos="fade-left">
          <img
            src={hero}
            alt="Hero Pemerintah"
            className="w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg drop-shadow-xl"
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;

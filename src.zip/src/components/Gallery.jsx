import React, { useEffect } from "react";
import NewsCard from "../components/NewsCard";
import { beritaTerkini } from "../constants/export";
import aos from "aos";
import "aos/dist/aos.css";
const Gallery = () => {
  useEffect(() => {
    aos.init({
      duration: 2000,
      delay: 200,
      once: false,
    });
  })
  return (
    <section className="py-16 bg-white">
      <div className="container">
        <h2 data-aos='fade-up' className="text-center text-2xl md:text-3xl font-bold mb-12">
          Kegiatan Dinas Pertanian Yapen
        </h2>
        <div className="grid-news">
          {beritaTerkini.map((item) => (
            <NewsCard key={item.id} {...item} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;

import React, { useEffect, useState } from "react";
import aos from "aos";
import "aos/dist/aos.css";
import NewsCard from "../components/NewsCard";
import { collection, getDocs, query, orderBy } from "firebase/firestore";
import { db } from "../firebase";
import Header from "../components/Header";
import Footer from "../components/Footer";

const News = () => {
  const [berita, setBerita] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    aos.init({ duration: 1000, delay: 100, once: true });
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const q = query(collection(db, "berita"), orderBy("date", "desc"));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        setBerita(data);
      } catch (err) {
        console.error("Gagal mengambil berita:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <Header />
      <main className="container py-16">
        <h1 data-aos="fade-up" className="text-3xl sm:text-4xl font-bold text-center mb-12">
          Berita
        </h1>

        {loading ? (
          <p className="text-center text-gray-500">Memuat berita...</p>
        ) : berita.length === 0 ? (
          <p className="text-center text-gray-500">Belum ada berita.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {berita.map((item, index) => (
              <NewsCard
                key={item.id}
                title={item.title}
                date={item.date.toDate().toLocaleDateString("id-ID", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
                location={item.location}
                image={item.image}
                slug={item.slug}
                dataAosDelay={index * 100}
              />
            ))}
          </div>
        )}
      </main>
      <Footer />
    </>
  );
};

export default News;

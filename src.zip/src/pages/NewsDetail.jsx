// src/pages/NewsDetail.jsx
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { beritaTerkini } from "../constants/export";
import Header from "../components/Header";
import Footer from "../components/Footer";

const NewsDetail = () => {
  const { slug } = useParams();
  const navigate = useNavigate();

  const berita = beritaTerkini.find((item) => item.slug === slug);

  if (!berita) {
    return (
      <div className="min-h-screen flex flex-col justify-center items-center">
        <p className="text-lg text-gray-600">Berita tidak ditemukan.</p>
        <button
          onClick={() => navigate(-1)}
          className="mt-4 bg-brand text-white px-4 py-2 rounded hover:bg-brand-light"
        >
          Kembali
        </button>
      </div>
    );
  }

  return (
    <>
      <Header />
      <main className="container py-12">
        <h1 className="text-2xl sm:text-3xl font-bold text-center mb-8">
          {berita.title}
        </h1>
        <img
          src={berita.image}
          alt={berita.title}
          className="w-full max-w-3xl mx-auto rounded-lg shadow-md mb-8 object-cover"
        />
        <div className="max-w-3xl mx-auto space-y-4 text-gray-800 text-justify">
          <p className="text-sm text-gray-500">
            {berita.date} &bull; {berita.location}
          </p>
          <p>{berita.content}</p>
        </div>
      </main>
      <Footer />
    </>
  );
};

export default NewsDetail;

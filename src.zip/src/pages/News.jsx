import React, { useEffect } from "react";
import aos from "aos";
import "aos/dist/aos.css";
import NewsCard from "../components/NewsCard";
import { beritaTerkini } from "../constants/export";
import Header from "../components/Header";
import Footer from "../components/Footer";

const News = () => {
  useEffect(() => {
    aos.init({
      duration: 1000,
      delay: 100,
      once: true,
    });
  }, []);

  return (
    <>
      <Header />
      <main className="container py-16">
        <h1
          data-aos="fade-up"
          className="text-3xl sm:text-4xl font-bold text-center mb-12"
        >
          Berita
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {beritaTerkini.map((item, index) => (
            <NewsCard key={item.id} {...item} dataAosDelay={index * 100} />
          ))}
        </div>
      </main>
      <Footer />
    </>
  );
};

export default News;

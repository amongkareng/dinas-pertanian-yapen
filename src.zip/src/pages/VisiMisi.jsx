import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import VisidanMisi from "../components/VisidanMisi";
const VisiMisi = () => {
  return (
    <>
      <Header />
      <VisidanMisi />
      <Footer />
    </>
  );
};

export default VisiMisi;

// src/pages/LandingPage.jsx
import React from "react";
import Hero from "../components/Hero";
import Gallery from "../components/Gallery";
import About from "../components/About";

const LandingPage = () => {
  return (
    <>
      <Hero />
      <Gallery />
      <About />
    </>
  );
};

export default LandingPage;

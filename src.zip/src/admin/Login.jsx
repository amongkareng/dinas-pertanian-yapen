import React, { useState } from "react";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const auth = getAuth();
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate("/admin/dashboard");
    } catch (err) {
      setError("Login gagal. Cek email dan password.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center px-4">
      <div className="grid grid-cols-1 md:grid-cols-2 bg-white rounded-xl shadow-lg overflow-hidden max-w-4xl w-full">
        {/* Left: Branding */}
        <div className="bg-brand text-white flex flex-col justify-center items-center px-6 py-12">
          <h1 className="text-2xl sm:text-3xl font-extrabold leading-tight text-center mb-2">
            WEBSITE <br /> DINAS PERTANIAN <br /> YAPEN - ADMIN
          </h1>
          <p className="text-sm opacity-90 mt-2 text-center max-w-xs">
            Panel login admin untuk mengelola berita dan konten
          </p>
        </div>

        {/* Right: Login Form */}
        <div className="p-8 md:p-10">
          <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">
            Selamat Datang!
          </h2>
          {error && (
            <p className="text-red-500 text-sm mb-4 text-center">{error}</p>
          )}
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button
              type="submit"
              className="w-full bg-[color:var(--color-brand)] text-white font-semibold py-2 rounded hover:bg-green-700 transition-colors"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;

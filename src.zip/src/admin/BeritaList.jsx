import React, { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import { Link } from "react-router-dom";

const BeritaList = () => {
  const [berita, setBerita] = useState([]);

  useEffect(() => {
    const fetchBerita = async () => {
      const querySnapshot = await getDocs(collection(db, "berita"));
      const beritaList = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setBerita(beritaList);
    };

    fetchBerita();
  }, []);

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold">Data Berita</h1>
        <Link
          to="/admin/berita/form"
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          + Tambah Berita
        </Link>
      </div>

      {berita.length === 0 ? (
        <p className="text-gray-500">Belum ada berita.</p>
      ) : (
        <ul className="space-y-4">
          {berita.map((item) => (
            <li key={item.id} className="p-4 border rounded shadow">
              <h2 className="font-semibold text-lg">{item.title}</h2>
              <p className="text-sm text-gray-600">{item.date?.toDate().toLocaleString()}</p>
              <p className="text-sm">{item.location}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default BeritaList;

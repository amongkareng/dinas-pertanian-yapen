import { BrowserRouter, Routes, Route } from "react-router-dom";
import PublicLayout from "./layouts/PublicLayout";
import AdminLayout from "./admin/Layout";
import PrivateRoute from "./components/PrivateRoute";

// Halaman publik
import LandingPage from "./pages/LandingPage";
import News from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import VisiMisi from "./pages/VisiMisi";
import Program from "./pages/Program";
import Struktur from "./pages/Struktur";

// Halaman admin
import Login from "./admin/Login";
import Dashboard from "./admin/Dashboard";
import BeritaList from "./admin/BeritaList";
import BeritaForm from "./admin/BeritaForm";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Rute publik dengan layout umum */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<LandingPage />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:slug" element={<NewsDetail />} />
          <Route path="/visimisi" element={<VisiMisi />} />
          <Route path="/program" element={<Program />} />
          <Route path="/struktur" element={<Struktur />} />
        </Route>

        {/* Rute login admin tanpa layout */}
        <Route path="/admin/login" element={<Login />} />

        {/* Rute admin (dilindungi PrivateRoute) */}
        <Route
          path="/admin"
          element={
            <PrivateRoute>
              <AdminLayout />
            </PrivateRoute>
          }
        >
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="berita" element={<BeritaList />} />
          <Route path="berita/form" element={<BeritaForm />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

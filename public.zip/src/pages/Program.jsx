import ProgramdanKegiatan from "../components/ProgramdanKegiatan";
const Program = () => {
  return (
    <>
      <ProgramdanKegiatan />
    </>
  );
};

export default Program;
